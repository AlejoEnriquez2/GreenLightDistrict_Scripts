
# Hello World

A simple example that just prints on each event. This examples serves as an equivalent of a "Hello World" program.

## Running

From the root directory of the repo, run the following command:

```bash
python experiment-runner/ examples/hello-world/RunnerConfig.py
```

## Results

The results are generated in the `examples/hello-world/experiments` folder.
